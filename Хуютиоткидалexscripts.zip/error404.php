<?php
include_once "inc/config.php";
?>
<html lang="ru"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="./files/<?php echo $favicon?>" type="image/x-icon">
		<link rel="shortcut icon" href="./files/<?php echo $favicon?>" type="image/x-icon">
    <title><?php echo $name_site?> - 404 Ошибка</title>

    <link rel="stylesheet" type="text/css" href="files/bootstrap.min.css">



  </head>
  <body class="" style="height:0%" style="background-image: url(img/<?php echo $bgc_site ?>);">





    <div class="app-content container text-xs-center">
      <div class="content-wrapper">

        <div class="content-body"><!--native-font-stack -->





<section id="description-list-alignment" style="margin-top:15%">


<div class="row">

        <h1 class="display-4 blue-grey darken-3">Страница не найдена</h1>

		<div class="col-lg-2 offset-lg-5">
		<button onclick="location.href='/'" style="margin-top:25px;color:#fff;background: #6c7a89!important; border: 0px solid; " type="button" class="bg-blue-grey bg-lighten-2  btn  btn-block mr-1 mb-1"> Hа главную</button>

</div>
</div>
</section>
        </div>
      </div>
    </div>
</body></html>
